var class_b_h1750_wrapper =
[
    [ "BH1750Wrapper", "class_b_h1750_wrapper.html#a269ed77d8ed445c6fb4a9aa6f33b39df", null ],
    [ "get_i2c_addr", "class_b_h1750_wrapper.html#abf1afbdda5863d3830fb3e54ce6813f1", null ],
    [ "init", "class_b_h1750_wrapper.html#a2f9561a5cce4fe2241a0e74f69e4dadb", null ],
    [ "read_data", "class_b_h1750_wrapper.html#ad6efe95b3e808a9a58db399ec2219332", null ],
    [ "is_initialized", "class_b_h1750_wrapper.html#aac6fd3165dff7b9356a136a0d677dbcc", null ],
    [ "get_type", "class_b_h1750_wrapper.html#a2b08ef514e8a5e0ad7d16e425492f136", null ],
    [ "configure", "class_b_h1750_wrapper.html#a721289913582b5222ca375cbbe6b43d6", null ],
    [ "sensor_", "class_b_h1750_wrapper.html#a6f64981c2e5ad9b14f2e33a840b84006", null ],
    [ "initialized_", "class_b_h1750_wrapper.html#ab0cdac42cf8911c4062e0771697c824f", null ]
];