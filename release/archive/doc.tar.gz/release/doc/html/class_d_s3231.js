var class_d_s3231 =
[
    [ "DS3231", "class_d_s3231.html#acc7723eadd86cc5f66c93066affbbeb7", null ],
    [ "set_time", "class_d_s3231.html#af68ef517aa7ff25393490211abc99fa8", null ],
    [ "get_time", "class_d_s3231.html#ad5a93c1afc0e44f96e08ce99258c5228", null ],
    [ "read_temperature", "class_d_s3231.html#a6668a479f66d288ae22f22a48b90327d", null ],
    [ "bin_to_bcd", "class_d_s3231.html#aa8ad05d783b0b67f10e8726863ff4891", null ],
    [ "bcd_to_bin", "class_d_s3231.html#ac7a9f58b408406930da56317de9f2a34", null ],
    [ "i2c_write_reg", "class_d_s3231.html#a2fa69b2c58e800b2a06e4966ca21b59c", null ],
    [ "i2c_read_reg", "class_d_s3231.html#ae3895581e62c411451d12de3e7558207", null ],
    [ "i2c", "class_d_s3231.html#afff19e512928fce8a6f9b50885df3732", null ],
    [ "ds3231_addr", "class_d_s3231.html#a6759d5d4e1ac0d12ab09016a42931aaf", null ]
];