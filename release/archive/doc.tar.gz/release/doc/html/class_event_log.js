var class_event_log =
[
    [ "to_string", "class_event_log.html#aff20f0a19416becca99ed24cf303a26f", null ],
    [ "id", "class_event_log.html#a5e0923e12450e6b7c782c7f6630f4563", null ],
    [ "timestamp", "class_event_log.html#aea248a425dedf15b5cee31ce2884db40", null ],
    [ "group", "class_event_log.html#a5209ffdb8dc4bf7f87f3ec44b2ae63e3", null ],
    [ "event", "class_event_log.html#a4ba1b6d820bf66740aac49fd299f1ea2", null ]
];