var class_event_manager =
[
    [ "EventManager", "class_event_manager.html#a89099b22114f158b5c530edfea52371d", null ],
    [ "~EventManager", "class_event_manager.html#ade6acde43327a4e792bb8256dd6350f0", null ],
    [ "init", "class_event_manager.html#ab9c4d0fbfc9cf7743eac02bee6223728", null ],
    [ "log_event", "class_event_manager.html#a741f96e4376a42712561ceca16646c1b", null ],
    [ "get_event", "class_event_manager.html#a884c7be3bfeb65337d9ee17dcca29563", null ],
    [ "get_event_count", "class_event_manager.html#ad6e0ee2d88a1a08c7ffa89168b86b76f", null ],
    [ "save_to_storage", "class_event_manager.html#a8ba3c824f2327911af8aabeef05392e1", null ],
    [ "load_from_storage", "class_event_manager.html#a64a6589e4a25afff95ee6f4b4e294203", null ],
    [ "events", "class_event_manager.html#a9d82f66074e141f352bb852654673536", null ],
    [ "eventCount", "class_event_manager.html#ab74418c8064525f34692dff74dd28d82", null ],
    [ "writeIndex", "class_event_manager.html#ad97f788895da6e30b3237982a7bcd810", null ],
    [ "eventMutex", "class_event_manager.html#a970381a54ae432d262830ad74048c94e", null ],
    [ "nextEventId", "class_event_manager.html#a31b1b079c272a1d7022ed84b01927186", null ],
    [ "needsPersistence", "class_event_manager.html#aed2eb3a8bc611f5594eb62304c7b4754", null ]
];