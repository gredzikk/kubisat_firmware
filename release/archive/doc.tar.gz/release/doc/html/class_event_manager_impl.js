var class_event_manager_impl =
[
    [ "EventManagerImpl", "class_event_manager_impl.html#a07861026e9c06832168372f64e958073", null ],
    [ "save_to_storage", "class_event_manager_impl.html#a8b1eeaf4f4faeb0132d02a71f8c1ef3c", null ],
    [ "load_from_storage", "class_event_manager_impl.html#a325106badcbbc2acf68025ef30ccd8f0", null ]
];