var class_h_m_c5883_l_wrapper =
[
    [ "HMC5883LWrapper", "class_h_m_c5883_l_wrapper.html#af0a0709fd3f48d8343794da5b3ee4f32", null ],
    [ "init", "class_h_m_c5883_l_wrapper.html#ab7a5997ae98ed9bc37fdd5ab0afe2fb2", null ],
    [ "read_data", "class_h_m_c5883_l_wrapper.html#adae87b75c84cc74246b606def4f90b43", null ],
    [ "is_initialized", "class_h_m_c5883_l_wrapper.html#aa8fef1832b14c758f6e73f88412615fd", null ],
    [ "get_type", "class_h_m_c5883_l_wrapper.html#a9be1b3abf26bb59943767ea271315f42", null ],
    [ "configure", "class_h_m_c5883_l_wrapper.html#aae28a5412098db267c5f61a638fa3ef6", null ],
    [ "sensor_", "class_h_m_c5883_l_wrapper.html#aa54e4887152b66f7f55b961165a82a71", null ],
    [ "initialized_", "class_h_m_c5883_l_wrapper.html#a78712f0f57a355113f2f6b5ba21aa3bf", null ]
];