var class_i_sensor =
[
    [ "~ISensor", "class_i_sensor.html#adbd5b40ebbf9a78b9845d22dddfac351", null ],
    [ "init", "class_i_sensor.html#a28051b0215d618d82556c8bb2c0abd29", null ],
    [ "read_data", "class_i_sensor.html#ab2c115be1f140c8e0a6e3b615a84ac05", null ],
    [ "is_initialized", "class_i_sensor.html#ab0583ca3425ecead66c8f2f2836825e8", null ],
    [ "get_type", "class_i_sensor.html#a9f49291a82b00d50ae215eeda8b74d94", null ],
    [ "configure", "class_i_sensor.html#aa5fd04ca51fa10cb8d0bcc835b14fb33", null ]
];