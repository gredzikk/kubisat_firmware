var class_sensor_wrapper =
[
    [ "SensorWrapper", "class_sensor_wrapper.html#a1702516a09884caf599fad7761dd04c1", null ],
    [ "get_instance", "class_sensor_wrapper.html#a915dcb3ade11776f3cbf4638313e92d1", null ],
    [ "sensor_init", "class_sensor_wrapper.html#a38e407ee27a363c52ad3851b18d760df", null ],
    [ "sensor_configure", "class_sensor_wrapper.html#a84e6c7d842f03f2d0c56ce8a4168aad8", null ],
    [ "sensor_read_data", "class_sensor_wrapper.html#a520a555a247b29df07db5b482e2504db", null ],
    [ "sensors", "class_sensor_wrapper.html#ae06e367395181a74d676c533393b47be", null ]
];