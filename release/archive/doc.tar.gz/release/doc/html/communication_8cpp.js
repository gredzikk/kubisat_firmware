var communication_8cpp =
[
    [ "initialize_radio", "communication_8cpp.html#a8f817ba4ed9164098cd3947f7cc3f749", null ],
    [ "outgoing", "communication_8cpp.html#a13c45747091f32644e83d65348c61232", null ],
    [ "msgCount", "communication_8cpp.html#a40654cfb6a32f90cfabc24c6a73398c3", null ],
    [ "lastSendTime", "communication_8cpp.html#a2843f69080a5607b99b835cc25627445", null ],
    [ "lastReceiveTime", "communication_8cpp.html#a910147e2cd3d3ef0590509f58c4b2afe", null ],
    [ "lastPrintTime", "communication_8cpp.html#ad56d9179eb2aa95b2115af8e89a20cb6", null ],
    [ "interval", "communication_8cpp.html#aaaceac04637cd33a7f3fffdd1711e6c5", null ]
];