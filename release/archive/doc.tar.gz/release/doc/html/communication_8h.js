var communication_8h =
[
    [ "initialize_radio", "communication_8h.html#a8f817ba4ed9164098cd3947f7cc3f749", null ],
    [ "on_receive", "communication_8h.html#a3f494105dee3a08e1244febc81982517", null ],
    [ "handle_uart_input", "communication_8h.html#a14ffba44d46e00b23bd72bdb3a4d58d1", null ],
    [ "send_message", "communication_8h.html#a8e567748586559735a2e90bb2ce7e871", null ],
    [ "send_frame", "communication_8h.html#ae6c6f3b673e7e83306da7ea2458d3241", null ],
    [ "split_and_send_message", "communication_8h.html#a207fb10d443babe78967d28c7565234a", null ],
    [ "execute_command", "group___command_system.html#ga52e8963095eccdf1045309bf31b4d705", null ],
    [ "send_event", "communication_8h.html#af49224563adb4bf0b91daa5ab78120ca", null ],
    [ "frame_process", "communication_8h.html#a8b9c5fd031b899c6c7867adcde4ac11f", null ],
    [ "frame_encode", "communication_8h.html#a3ae6df528775be58890bf406c906a056", null ],
    [ "frame_decode", "communication_8h.html#a0b3438ff642c0934321101e1f0b8d82d", null ],
    [ "frame_build", "communication_8h.html#a70248162b9a616f543f470d88ccdf4a6", null ],
    [ "determine_unit", "communication_8h.html#a1df3cc2d97de283e0c229b2d87f39b47", null ]
];