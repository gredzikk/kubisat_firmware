var event__manager_8cpp =
[
    [ "check_power_events", "event__manager_8cpp.html#a3a1b3fdef7c62da5c917d3006cdc65dd", null ],
    [ "eventLogId", "event__manager_8cpp.html#ab144678e47784f421d98c3dfdbb53dc8", null ],
    [ "lastPowerState", "event__manager_8cpp.html#a2d4329f1e2606ca8f8535dae8c08afe5", null ],
    [ "FALL_RATE_THRESHOLD", "event__manager_8cpp.html#a234988dfb88db38997bd921cd5c32457", null ],
    [ "FALLING_TREND_REQUIRED", "event__manager_8cpp.html#ae4e7da8cdf52e447acd5705d930759cf", null ],
    [ "VOLTAGE_LOW_THRESHOLD", "event__manager_8cpp.html#aa1095ab71c42b3eaed0492aec0941972", null ],
    [ "VOLTAGE_OVERCHARGE_THRESHOLD", "event__manager_8cpp.html#a98ed7b83dd5e1a54a096ca9bb3456163", null ],
    [ "fallingTrendCount", "event__manager_8cpp.html#ad4a2e48e0a0e0d5aa49dd6c2aa12d8fb", null ],
    [ "lastSolarState", "event__manager_8cpp.html#a908d9cb4eb9ec61d273f6770660bbb8e", null ],
    [ "lastUSBState", "event__manager_8cpp.html#a0592f758055ae8683676ff86ae7ae9e1", null ],
    [ "systemClock", "event__manager_8cpp.html#abfd573c8a839ac00ea3b96d691ea11c3", null ],
    [ "eventManager", "event__manager_8cpp.html#a2a686792b51ec2b9e1b7bfc9faef92f7", null ]
];