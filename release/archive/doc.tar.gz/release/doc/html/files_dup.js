var files_dup =
[
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "build_number.h", "build__number_8h.html", "build__number_8h" ],
    [ "includes.h", "includes_8h.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];