var group___clock_commands =
[
    [ "handle_time", "group___clock_commands.html#gaece0975a9dd699742e1db5a411bcc93c", null ],
    [ "handle_timezone_offset", "group___clock_commands.html#ga026ff03f9aa86d2bd305090836f4a79a", null ],
    [ "handle_clock_sync_interval", "group___clock_commands.html#gae0bd51ede980e34daf37928a625bd170", null ],
    [ "handle_get_last_sync_time", "group___clock_commands.html#ga8fad2991aef05583a47a5b1072ffece0", null ],
    [ "systemClock", "group___clock_commands.html#gabfd573c8a839ac00ea3b96d691ea11c3", null ]
];