var group___event_commands =
[
    [ "handle_get_last_events", "group___event_commands.html#ga9a7182db399c2b40ea66db5989d10471", null ],
    [ "hadnle_get_event_count", "group___event_commands.html#gaaa3951cee1a13c3f497c96c0f3be9f95", null ]
];