var group___g_p_s_commands =
[
    [ "handle_gps_power_status", "group___g_p_s_commands.html#ga926ab365cf351bb507a8c38066ee2eeb", null ],
    [ "handle_enable_gps_uart_passthrough", "group___g_p_s_commands.html#ga3e4c6db6e933a1ff77f3ac52ce1c44be", null ],
    [ "handle_get_rmc_data", "group___g_p_s_commands.html#ga8e18759b90b7902e535f50aceae81f2e", null ],
    [ "handle_get_gga_data", "group___g_p_s_commands.html#ga617ca7e129f14b0ca4f0d6eb333cbf27", null ]
];