var power__commands_8cpp =
[
    [ "handle_get_power_manager_ids", "group___power_commands.html#ga847b0ed9bf4c252edb1440831739e1ca", null ],
    [ "handle_get_voltage_battery", "group___power_commands.html#ga06487ba124c57bc39009eb235ec8cab4", null ],
    [ "handle_get_voltage_5v", "group___power_commands.html#ga24497d675dc02a7ec46ed0327a9de54a", null ],
    [ "handle_get_current_charge_usb", "group___power_commands.html#ga6e5a897c92aaeae8b2fb25faa50bb19d", null ],
    [ "handle_get_current_charge_solar", "group___power_commands.html#gacda455c78e43fa4ad2a93215b440c0ef", null ],
    [ "handle_get_current_charge_total", "group___power_commands.html#gaf14f25e1c7a2f89881a0f9fbcb7f1807", null ],
    [ "handle_get_current_draw", "group___power_commands.html#ga31c33c0ee51185939be5c642affdb6b8", null ]
];