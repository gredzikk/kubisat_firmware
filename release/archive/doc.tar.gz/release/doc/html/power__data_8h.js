var power__data_8h =
[
    [ "PowerData", "struct_power_data.html", "struct_power_data" ],
    [ "g_power_data", "power__data_8h.html#a93c082e47d53a4ba9d09ec5bfa85ce8f", null ]
];