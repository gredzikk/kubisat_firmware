var searchData=
[
  ['uart_5ferror_0',['UART_ERROR',['../event__manager_8h.html#a0270a0464efae26aefb8cf32a45e20adae7987a4741412b725a5a1a24867f9b62',1,'event_manager.h']]],
  ['uart_5fmutex_1',['uart_mutex',['../utils_8cpp.html#a1a79e1136e3879e08124c966946cf7b4',1,'utils.cpp']]],
  ['uart_5fprint_2',['uart_print',['../utils_8cpp.html#acd86977d05fa330749958ace0f2798de',1,'uart_print(const std::string &amp;msg, bool logToFile, uart_inst_t *uart):&#160;utils.cpp'],['../utils_8h.html#a1742e86aa0036799f971dea15081f283',1,'uart_print(const std::string &amp;msg, bool logToFile=false, uart_inst_t *uart=DEBUG_UART_PORT):&#160;utils.cpp']]],
  ['unconfigured_5fpower_5fdown_3',['UNCONFIGURED_POWER_DOWN',['../class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a9d4b69a5f725a5105a480e2e5d67e851',1,'BH1750']]],
  ['undefined_4',['UNDEFINED',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8fa0db45d2a4141101bdfe48e3314cfbca3',1,'protocol.h']]],
  ['unit_5',['unit',['../struct_frame.html#a6481c04c9c112a41a50c24696454afa8',1,'Frame']]],
  ['update_5fgga_5ftokens_6',['update_gga_tokens',['../class_n_m_e_a_data.html#ac7387e75e4687d1f42daa040651243ea',1,'NMEAData']]],
  ['update_5frmc_5ftokens_7',['update_rmc_tokens',['../class_n_m_e_a_data.html#ab02d8e25a1def19c8e2c70a8fa84ac73',1,'NMEAData']]],
  ['usb_5fconnected_8',['USB_CONNECTED',['../event__manager_8h.html#a8b04683add0105a3bf3200eee3d9d3e6aea2afd0110180e8af5bf95a583f9dd13',1,'event_manager.h']]],
  ['usb_5fcurrent_5fthreshold_9',['USB_CURRENT_THRESHOLD',['../class_power_manager.html#afc4246cc3b434053c59cf2dcccf4bc64',1,'PowerManager']]],
  ['usb_5fdisconnected_10',['USB_DISCONNECTED',['../event__manager_8h.html#a8b04683add0105a3bf3200eee3d9d3e6a3a026550c6805c690d88a618aff891c9',1,'event_manager.h']]],
  ['utils_2ecpp_11',['utils.cpp',['../utils_8cpp.html',1,'']]],
  ['utils_2eh_12',['utils.h',['../utils_8h.html',1,'']]],
  ['utils_5fconverters_2ecpp_13',['utils_converters.cpp',['../utils__converters_8cpp.html',1,'']]]
];
