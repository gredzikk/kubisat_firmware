var searchData=
[
  ['value_0',['value',['../struct_frame.html#a118ecfcbf5afd93d394f667829adf26a',1,'Frame']]],
  ['value_5funit_5ftype_5fto_5fstring_1',['value_unit_type_to_string',['../protocol_8h.html#a29531ed9ad98ab78384a8a2f37f4e77d',1,'value_unit_type_to_string(ValueUnit unit):&#160;utils_converters.cpp'],['../utils__converters_8cpp.html#a29531ed9ad98ab78384a8a2f37f4e77d',1,'value_unit_type_to_string(ValueUnit unit):&#160;utils_converters.cpp']]],
  ['valueunit_2',['ValueUnit',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8f',1,'protocol.h']]],
  ['volt_3',['VOLT',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8fad99987f942ecbf2eea5d50ebf50723e6',1,'protocol.h']]],
  ['voltage_5flow_5fthreshold_4',['VOLTAGE_LOW_THRESHOLD',['../class_power_manager.html#a426dcedc762549ed6c408708bd61b94e',1,'PowerManager::VOLTAGE_LOW_THRESHOLD'],['../event__manager_8cpp.html#aa1095ab71c42b3eaed0492aec0941972',1,'VOLTAGE_LOW_THRESHOLD:&#160;event_manager.cpp']]],
  ['voltage_5fovercharge_5fthreshold_5',['VOLTAGE_OVERCHARGE_THRESHOLD',['../class_power_manager.html#a4e28f40bee3fd8e6df12178663159783',1,'PowerManager::VOLTAGE_OVERCHARGE_THRESHOLD'],['../event__manager_8cpp.html#a98ed7b83dd5e1a54a096ca9bb3456163',1,'VOLTAGE_OVERCHARGE_THRESHOLD:&#160;event_manager.cpp']]]
];
