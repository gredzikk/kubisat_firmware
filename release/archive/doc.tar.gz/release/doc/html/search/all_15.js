var searchData=
[
  ['year_0',['year',['../structds3231__data__t.html#aaee28b1b2ecbfe8070da619e5f54e31e',1,'ds3231_data_t']]]
];
