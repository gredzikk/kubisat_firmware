var searchData=
[
  ['filehandle_0',['FileHandle',['../struct_file_handle.html',1,'']]],
  ['frame_1',['Frame',['../struct_frame.html',1,'']]]
];
