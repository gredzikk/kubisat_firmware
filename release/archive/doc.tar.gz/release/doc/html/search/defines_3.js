var searchData=
[
  ['event_5fbuffer_5fsize_0',['EVENT_BUFFER_SIZE',['../event__manager_8h.html#acc4dda1aaabc9862fe79fd94e0b722bf',1,'event_manager.h']]]
];
