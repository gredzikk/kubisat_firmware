var searchData=
[
  ['sd_5fcard_5fdetect_5fpin_0',['SD_CARD_DETECT_PIN',['../pin__config_8h.html#a9f82e7c5f6814db47f585c49a25322e3',1,'pin_config.h']]],
  ['sd_5fcs_5fpin_1',['SD_CS_PIN',['../pin__config_8h.html#a04d57a6c18b2d5e81f31093e58ed0c62',1,'pin_config.h']]],
  ['sd_5fmiso_5fpin_2',['SD_MISO_PIN',['../pin__config_8h.html#ad3aea67d9c7c7dc0be847a1467786abb',1,'pin_config.h']]],
  ['sd_5fmosi_5fpin_3',['SD_MOSI_PIN',['../pin__config_8h.html#a1150cf94392cb54e7e979e6b69f210fb',1,'pin_config.h']]],
  ['sd_5fsck_5fpin_4',['SD_SCK_PIN',['../pin__config_8h.html#a712b6e5405cc83d1a7c1a30f198df12a',1,'pin_config.h']]],
  ['sd_5fspi_5fport_5',['SD_SPI_PORT',['../pin__config_8h.html#ae8e100b2951ae1785ada736a7d960a77',1,'pin_config.h']]],
  ['spi_5fport_6',['SPI_PORT',['../pin__config_8h.html#a8112c985f7444e82198d7571ce0a9160',1,'pin_config.h']]],
  ['sx1278_5fcs_7',['SX1278_CS',['../pin__config_8h.html#a7780b3759fe45ccad39487fe5f5eab78',1,'pin_config.h']]],
  ['sx1278_5fmiso_8',['SX1278_MISO',['../pin__config_8h.html#a2a961da12f0cb47e0456db30261047b8',1,'pin_config.h']]],
  ['sx1278_5fmosi_9',['SX1278_MOSI',['../pin__config_8h.html#a0752355e6d262273b2059c07a7535848',1,'pin_config.h']]],
  ['sx1278_5fsck_10',['SX1278_SCK',['../pin__config_8h.html#a984f1a74ecb2af81a660ba77c0d47ddc',1,'pin_config.h']]]
];
