var searchData=
[
  ['powerevent_0',['PowerEvent',['../event__manager_8h.html#a8b04683add0105a3bf3200eee3d9d3e6',1,'event_manager.h']]]
];
