var searchData=
[
  ['none_0',['NONE',['../protocol_8h.html#a1a30b781d6fac5ca0b850dd8b3726d8dab50339a10e1de285ac99d4c3990b8693',1,'NONE:&#160;protocol.h'],['../protocol_8h.html#a0e0f0f1661d7aeb71ed9698bff6c6383ab50339a10e1de285ac99d4c3990b8693',1,'NONE:&#160;protocol.h']]],
  ['not_5fallowed_1',['NOT_ALLOWED',['../protocol_8h.html#a0e0f0f1661d7aeb71ed9698bff6c6383a4596302bc1e8ce6e62188e769aac94cf',1,'protocol.h']]]
];
