var searchData=
[
  ['value_5funit_5ftype_5fto_5fstring_0',['value_unit_type_to_string',['../protocol_8h.html#a29531ed9ad98ab78384a8a2f37f4e77d',1,'value_unit_type_to_string(ValueUnit unit):&#160;utils_converters.cpp'],['../utils__converters_8cpp.html#a29531ed9ad98ab78384a8a2f37f4e77d',1,'value_unit_type_to_string(ValueUnit unit):&#160;utils_converters.cpp']]]
];
