var searchData=
[
  ['ds3231_5fdata_5ft_0',['ds3231_data_t',['../_d_s3231_8h.html#a4da45e4018de364d6d526e46679548e0',1,'DS3231.h']]],
  ['ds3231_5ft_1',['ds3231_t',['../_d_s3231_8h.html#a6fe5dac69ce312f38dd11e57c40d80c4',1,'DS3231.h']]]
];
