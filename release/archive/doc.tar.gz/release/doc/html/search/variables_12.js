var searchData=
[
  ['uart_5fmutex_0',['uart_mutex',['../utils_8cpp.html#a1a79e1136e3879e08124c966946cf7b4',1,'utils.cpp']]],
  ['unit_1',['unit',['../struct_frame.html#a6481c04c9c112a41a50c24696454afa8',1,'Frame']]],
  ['usb_5fcurrent_5fthreshold_2',['USB_CURRENT_THRESHOLD',['../class_power_manager.html#afc4246cc3b434053c59cf2dcccf4bc64',1,'PowerManager']]]
];
