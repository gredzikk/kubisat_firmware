var searchData=
[
  ['calib_5fparams_0',['calib_params',['../class_b_m_e280.html#ab61c36455871833809cff71b5fd3397f',1,'BME280']]],
  ['century_1',['century',['../structds3231__data__t.html#a4728d8488a2cacc95d111a1721965e37',1,'ds3231_data_t']]],
  ['ch1_5fen_2',['ch1_en',['../struct_i_n_a3221_1_1conf__reg__t.html#ab763a286b340cd4cda77c7d59411c244',1,'INA3221::conf_reg_t']]],
  ['ch2_5fen_3',['ch2_en',['../struct_i_n_a3221_1_1conf__reg__t.html#a04f0db25a67d43c2ad63dfa5dd2fb1ee',1,'INA3221::conf_reg_t']]],
  ['ch3_5fen_4',['ch3_en',['../struct_i_n_a3221_1_1conf__reg__t.html#a3b03b9771ee7a690d62d6fd4fe644867',1,'INA3221::conf_reg_t']]],
  ['charging_5fsolar_5factive_5f_5',['charging_solar_active_',['../class_power_manager.html#a81537e3dfbf977ed5e9346a0a2673743',1,'PowerManager']]],
  ['charging_5fusb_5factive_5f_6',['charging_usb_active_',['../class_power_manager.html#a9a117ff74fc946d35061bbb29b144080',1,'PowerManager']]],
  ['command_7',['command',['../struct_frame.html#a2fa1a9d8fa7eb710234eb68bf376e6de',1,'Frame']]],
  ['commandhandlers_8',['commandHandlers',['../group___command_system.html#ga04a0515603ba347ef314678876f3fa26',1,'commandHandlers:&#160;commands.cpp'],['../group___command_system.html#ga04a0515603ba347ef314678876f3fa26',1,'commandHandlers:&#160;commands.cpp'],['../group___command_system.html#ga04a0515603ba347ef314678876f3fa26',1,'commandHandlers:&#160;commands.cpp']]],
  ['conv_5fready_9',['conv_ready',['../struct_i_n_a3221_1_1masken__reg__t.html#a1cd5f40e6d2a70f0c8e9d382932886d6',1,'INA3221::masken_reg_t']]],
  ['crit_5falert_5fch1_10',['crit_alert_ch1',['../struct_i_n_a3221_1_1masken__reg__t.html#a560db4fe3259835dc8fd38c22ebe1ef5',1,'INA3221::masken_reg_t']]],
  ['crit_5falert_5fch2_11',['crit_alert_ch2',['../struct_i_n_a3221_1_1masken__reg__t.html#ad3eb33d7ac40cf7870031727a15fea6b',1,'INA3221::masken_reg_t']]],
  ['crit_5falert_5fch3_12',['crit_alert_ch3',['../struct_i_n_a3221_1_1masken__reg__t.html#ad9b927fca7fe260fead7c53dd7cd1141',1,'INA3221::masken_reg_t']]],
  ['crit_5falert_5flatch_5fen_13',['crit_alert_latch_en',['../struct_i_n_a3221_1_1masken__reg__t.html#a6c80d96e861fcb123d3fb6ec665b5c8b',1,'INA3221::masken_reg_t']]]
];
