var searchData=
[
  ['gga_5fmutex_5f_0',['gga_mutex_',['../class_n_m_e_a_data.html#ac6581aa69dfe380d6d0ae9c5b74bec39',1,'NMEAData']]],
  ['gga_5ftokens_5f_1',['gga_tokens_',['../class_n_m_e_a_data.html#a37d9f4f27f6b0b16e2649bce3a2a25f7',1,'NMEAData']]],
  ['group_2',['group',['../struct_frame.html#abd1ff8cb6b3d53706a97ea15727ddd4f',1,'Frame::group'],['../class_event_log.html#a5209ffdb8dc4bf7f87f3ec44b2ae63e3',1,'EventLog::group'],['../event__manager_8h.html#ad4291fcb880eb5ecb178b53e32f55741',1,'group:&#160;event_manager.h']]]
];
