var searchData=
[
  ['header_0',['header',['../struct_frame.html#ae969aefac1bd27476536aae3de4eacee',1,'Frame']]],
  ['hours_1',['hours',['../structds3231__data__t.html#af9a684044ad2809b7933046586e923a4',1,'ds3231_data_t']]]
];
