var searchData=
[
  ['operationtype_0',['operationType',['../struct_frame.html#a6ad0b81e9434fee37a64535a0c58facb',1,'Frame']]],
  ['outgoing_1',['outgoing',['../communication_8cpp.html#a13c45747091f32644e83d65348c61232',1,'communication.cpp']]]
];
