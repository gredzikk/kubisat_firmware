var send_8cpp =
[
    [ "send_message", "send_8cpp.html#a42881e6476e0ce51ee9f6a99a7318d3b", null ],
    [ "send_frame", "send_8cpp.html#ae6c6f3b673e7e83306da7ea2458d3241", null ],
    [ "split_and_send_message", "send_8cpp.html#a207fb10d443babe78967d28c7565234a", null ]
];