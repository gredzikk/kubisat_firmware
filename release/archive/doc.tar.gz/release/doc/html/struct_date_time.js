var struct_date_time =
[
    [ "year", "struct_date_time.html#a0a61d60280541502e47f9a7fd6e1c8d2", null ],
    [ "month", "struct_date_time.html#ac895afb51c74941c50205f746b709148", null ],
    [ "day", "struct_date_time.html#a727866b5ecdfda1edf946efe86aa74af", null ],
    [ "hour", "struct_date_time.html#ad7812eb3752d2309263267d4bc3c79a0", null ],
    [ "minute", "struct_date_time.html#abc5bfa47937548c7aaad1970ba759af3", null ],
    [ "second", "struct_date_time.html#afb74c1792d0f0f9d3b0d2295554fa39d", null ],
    [ "weekday", "struct_date_time.html#a5b762acddaaa0138a96b05159f2c2e23", null ]
];