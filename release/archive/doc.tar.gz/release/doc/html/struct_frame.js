var struct_frame =
[
    [ "header", "struct_frame.html#ae969aefac1bd27476536aae3de4eacee", null ],
    [ "direction", "struct_frame.html#a380c3287d8bc0718ed7a3b93e303dbe5", null ],
    [ "operationType", "struct_frame.html#a6ad0b81e9434fee37a64535a0c58facb", null ],
    [ "group", "struct_frame.html#abd1ff8cb6b3d53706a97ea15727ddd4f", null ],
    [ "command", "struct_frame.html#a2fa1a9d8fa7eb710234eb68bf376e6de", null ],
    [ "value", "struct_frame.html#a118ecfcbf5afd93d394f667829adf26a", null ],
    [ "unit", "struct_frame.html#a6481c04c9c112a41a50c24696454afa8", null ],
    [ "footer", "struct_frame.html#a30e584ccb03562f0bbd5356562a462c1", null ]
];