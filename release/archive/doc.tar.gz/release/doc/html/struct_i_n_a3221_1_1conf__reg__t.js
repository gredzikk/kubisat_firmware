var struct_i_n_a3221_1_1conf__reg__t =
[
    [ "mode_shunt_en", "struct_i_n_a3221_1_1conf__reg__t.html#a663e6b256bd24e6b9161e35a36aac0fc", null ],
    [ "mode_bus_en", "struct_i_n_a3221_1_1conf__reg__t.html#aec23450c7605d5c0013b8fa27a72056c", null ],
    [ "mode_continious_en", "struct_i_n_a3221_1_1conf__reg__t.html#af152fe0cc058165ef37c6986e9d8177f", null ],
    [ "shunt_conv_time", "struct_i_n_a3221_1_1conf__reg__t.html#a23045ef81337be493027a335570ac906", null ],
    [ "bus_conv_time", "struct_i_n_a3221_1_1conf__reg__t.html#ae5d8ffdeff64ebc70c018901b6e45319", null ],
    [ "avg_mode", "struct_i_n_a3221_1_1conf__reg__t.html#a2336f127fcd7bf551db4142c495c54f5", null ],
    [ "ch3_en", "struct_i_n_a3221_1_1conf__reg__t.html#a3b03b9771ee7a690d62d6fd4fe644867", null ],
    [ "ch2_en", "struct_i_n_a3221_1_1conf__reg__t.html#a04f0db25a67d43c2ad63dfa5dd2fb1ee", null ],
    [ "ch1_en", "struct_i_n_a3221_1_1conf__reg__t.html#ab763a286b340cd4cda77c7d59411c244", null ],
    [ "reset", "struct_i_n_a3221_1_1conf__reg__t.html#aaa94a05775ef55a4624e85c8ad9ffd4d", null ]
];