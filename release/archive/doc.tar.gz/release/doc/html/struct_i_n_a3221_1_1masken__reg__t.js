var struct_i_n_a3221_1_1masken__reg__t =
[
    [ "conv_ready", "struct_i_n_a3221_1_1masken__reg__t.html#a1cd5f40e6d2a70f0c8e9d382932886d6", null ],
    [ "timing_ctrl_alert", "struct_i_n_a3221_1_1masken__reg__t.html#a592f9e0661f6261694437ae3769ac17a", null ],
    [ "pwr_valid_alert", "struct_i_n_a3221_1_1masken__reg__t.html#aa1dab85b61d3075ff5633e32f497c68a", null ],
    [ "warn_alert_ch3", "struct_i_n_a3221_1_1masken__reg__t.html#a12aeac3138ab9f59e72119c3bec458a8", null ],
    [ "warn_alert_ch2", "struct_i_n_a3221_1_1masken__reg__t.html#ab8cc409f51b0b1a101bc50b4eb87c0de", null ],
    [ "warn_alert_ch1", "struct_i_n_a3221_1_1masken__reg__t.html#afe97e7bf1a89ddc7ba8a9296e65a7352", null ],
    [ "shunt_sum_alert", "struct_i_n_a3221_1_1masken__reg__t.html#a36c00c8592655c20461730b551378212", null ],
    [ "crit_alert_ch3", "struct_i_n_a3221_1_1masken__reg__t.html#ad9b927fca7fe260fead7c53dd7cd1141", null ],
    [ "crit_alert_ch2", "struct_i_n_a3221_1_1masken__reg__t.html#ad3eb33d7ac40cf7870031727a15fea6b", null ],
    [ "crit_alert_ch1", "struct_i_n_a3221_1_1masken__reg__t.html#a560db4fe3259835dc8fd38c22ebe1ef5", null ],
    [ "crit_alert_latch_en", "struct_i_n_a3221_1_1masken__reg__t.html#a6c80d96e861fcb123d3fb6ec665b5c8b", null ],
    [ "warn_alert_latch_en", "struct_i_n_a3221_1_1masken__reg__t.html#a96cadcb3794fddf964748ba6669b9b2f", null ],
    [ "shunt_sum_en_ch3", "struct_i_n_a3221_1_1masken__reg__t.html#abb9fdf6a9d488261b13b8918035856ea", null ],
    [ "shunt_sum_en_ch2", "struct_i_n_a3221_1_1masken__reg__t.html#a8f65bef9c6f13a79dbd22116ee170295", null ],
    [ "shunt_sum_en_ch1", "struct_i_n_a3221_1_1masken__reg__t.html#aba8ce8bc8bbe8bac4bbc78043d16096e", null ],
    [ "reserved", "struct_i_n_a3221_1_1masken__reg__t.html#ab6a76a29c77b8315e11e434cfab1e614", null ]
];