var struct_power_data =
[
    [ "voltage_battery", "struct_power_data.html#a48178e2b94b8f3b7953a0bc0a17386b6", null ],
    [ "voltage_5v", "struct_power_data.html#ab0c5257bb772ec7e8ce49257e799a359", null ],
    [ "current_charge_usb", "struct_power_data.html#a62b6efafe3f9e4b27093101f2ef5822f", null ],
    [ "current_charge_solar", "struct_power_data.html#a4073aead10073f45a2bfc5a6c073ec23", null ],
    [ "current_draw", "struct_power_data.html#aaa41c3972e180351253b3e4f71683dd7", null ],
    [ "is_charging_solar", "struct_power_data.html#a97c6c3ed73f41ce7899f6da5526395c9", null ],
    [ "is_charging_usb", "struct_power_data.html#a2d9b36216a03f2f1db2190aae9b28e9b", null ]
];