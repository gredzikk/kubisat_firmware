var structds3231__data__t =
[
    [ "seconds", "structds3231__data__t.html#ab26ab1755b5a872aa78172182e8b54da", null ],
    [ "minutes", "structds3231__data__t.html#a87a05374fcbe47c9ce7e9abe28d864d3", null ],
    [ "hours", "structds3231__data__t.html#af9a684044ad2809b7933046586e923a4", null ],
    [ "day", "structds3231__data__t.html#aee218cfb9904c839652d2edbfc0922b8", null ],
    [ "date", "structds3231__data__t.html#a423c1692433240cff62cef05fec405f1", null ],
    [ "month", "structds3231__data__t.html#a00ef663eddc6780133279fcb2a4fddea", null ],
    [ "century", "structds3231__data__t.html#a4728d8488a2cacc95d111a1721965e37", null ],
    [ "year", "structds3231__data__t.html#aaee28b1b2ecbfe8070da619e5f54e31e", null ]
];