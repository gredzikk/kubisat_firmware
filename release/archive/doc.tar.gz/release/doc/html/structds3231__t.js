var structds3231__t =
[
    [ "i2c", "structds3231__t.html#a3a28c0ca59958e73e60600b04d6b6ef8", null ],
    [ "ds3231_addr", "structds3231__t.html#a5fc8e10745577859f508fa2a36cdbe89", null ]
];