var utils_8h =
[
    [ "uart_print", "utils_8h.html#a1742e86aa0036799f971dea15081f283", null ],
    [ "crc16", "utils_8h.html#a662798a1967f4a4ea55257255d0fbbf4", null ]
];