var _b_h1750_8h =
[
    [ "BH1750", "class_b_h1750.html", "class_b_h1750" ],
    [ "_BH1750_DEVICE_ID", "_b_h1750_8h.html#aad341433a609b42d1151895817f1745c", null ],
    [ "_BH1750_MTREG_MIN", "_b_h1750_8h.html#a789aa19af17a7bd05257004f47175178", null ],
    [ "_BH1750_MTREG_MAX", "_b_h1750_8h.html#aceb598336053a7a1277bb3d098c52db0", null ],
    [ "_BH1750_DEFAULT_MTREG", "_b_h1750_8h.html#ab60764acdd32eebac725b0d62ee417f4", null ]
];