var _d_s3231_8h =
[
    [ "DateTime", "struct_date_time.html", "struct_date_time" ],
    [ "DS3231", "class_d_s3231.html", "class_d_s3231" ]
];