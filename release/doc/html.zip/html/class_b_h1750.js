var class_b_h1750 =
[
    [ "Mode", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0", [
      [ "UNCONFIGURED_POWER_DOWN", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a9d4b69a5f725a5105a480e2e5d67e851", null ],
      [ "POWER_ON", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a3d6fc432ff9e2d9b890c591179a4401e", null ],
      [ "RESET", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0ab5859d8721cfdc0312b2838b9c985bc1", null ],
      [ "CONTINUOUS_HIGH_RES_MODE", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0afd7abdb36f193409d2a88bf176763911", null ],
      [ "CONTINUOUS_HIGH_RES_MODE_2", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0ac12663db8fda5e471cb5b946171a20b1", null ],
      [ "CONTINUOUS_LOW_RES_MODE", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0ac32e5d6f3f1a6561e874a4a8fd60723f", null ],
      [ "ONE_TIME_HIGH_RES_MODE", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0ae6af2d70de1e4c57254d72b3b1b57e35", null ],
      [ "ONE_TIME_HIGH_RES_MODE_2", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a459f53ea14165ac4c845757c4c93022a", null ],
      [ "ONE_TIME_LOW_RES_MODE", "class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a4f81ddfb660e4f3e0bc4228c61ff6dc6", null ]
    ] ],
    [ "BH1750", "class_b_h1750.html#ad3621c02c56c15e4f3d40f0974a376f2", null ],
    [ "begin", "class_b_h1750.html#ae0e57ed9ecc08464a6b98b733d420e11", null ],
    [ "configure", "class_b_h1750.html#ab4f497d6aabaa34ba1ace42206bca286", null ],
    [ "readLightLevel", "class_b_h1750.html#a15a9940a67c05b9f9a781b032fa4701e", null ],
    [ "write8", "class_b_h1750.html#a3208587c6a4e0a6428f53c176c0b2970", null ],
    [ "_i2c_addr", "class_b_h1750.html#ab332014adec6fccc44f11da4034e788e", null ]
];