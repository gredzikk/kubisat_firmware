var class_b_h1750_wrapper =
[
    [ "BH1750Wrapper", "class_b_h1750_wrapper.html#a269ed77d8ed445c6fb4a9aa6f33b39df", null ],
    [ "get_i2c_addr", "class_b_h1750_wrapper.html#abf1afbdda5863d3830fb3e54ce6813f1", null ],
    [ "init", "class_b_h1750_wrapper.html#a2f9561a5cce4fe2241a0e74f69e4dadb", null ],
    [ "readData", "class_b_h1750_wrapper.html#a150e9bb5fb1185d6b1619565c66c5f62", null ],
    [ "isInitialized", "class_b_h1750_wrapper.html#a17eee3fe5b77e07d5aceed51c5277709", null ],
    [ "getType", "class_b_h1750_wrapper.html#aa107682828326c965d10db863e704bde", null ],
    [ "configure", "class_b_h1750_wrapper.html#a721289913582b5222ca375cbbe6b43d6", null ],
    [ "sensor", "class_b_h1750_wrapper.html#a254f46eb45a19e87f32ae62ca4ef0135", null ],
    [ "initialized", "class_b_h1750_wrapper.html#a260b8f66366a5174cc8b0b92dda72e31", null ]
];