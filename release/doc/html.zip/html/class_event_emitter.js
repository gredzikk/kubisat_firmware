var class_event_emitter =
[
    [ "emit", "class_event_emitter.html#a539d733505f9a793439a9cfc4f2af079", null ]
];