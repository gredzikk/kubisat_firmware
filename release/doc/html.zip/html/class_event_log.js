var class_event_log =
[
    [ "toString", "class_event_log.html#adb17c412276c8678289395607c493e7e", null ],
    [ "id", "class_event_log.html#a5e0923e12450e6b7c782c7f6630f4563", null ],
    [ "timestamp", "class_event_log.html#aea248a425dedf15b5cee31ce2884db40", null ],
    [ "group", "class_event_log.html#a5209ffdb8dc4bf7f87f3ec44b2ae63e3", null ],
    [ "event", "class_event_log.html#a4ba1b6d820bf66740aac49fd299f1ea2", null ]
];