var class_event_manager =
[
    [ "EventManager", "class_event_manager.html#a89099b22114f158b5c530edfea52371d", null ],
    [ "~EventManager", "class_event_manager.html#ade6acde43327a4e792bb8256dd6350f0", null ],
    [ "init", "class_event_manager.html#ab9c4d0fbfc9cf7743eac02bee6223728", null ],
    [ "logEvent", "class_event_manager.html#ae73a56091dc8713bb86a11abb6742a14", null ],
    [ "getEvent", "class_event_manager.html#a00648cfe8c39fbd59cc4c593113e5573", null ],
    [ "getEventCount", "class_event_manager.html#abd8630355ef48f46c5286f232adb5993", null ],
    [ "saveToStorage", "class_event_manager.html#ad369ac9b7ab0251070e0075745836a40", null ],
    [ "loadFromStorage", "class_event_manager.html#a6722258e4e3df939224d07786427afc9", null ],
    [ "events", "class_event_manager.html#a9d82f66074e141f352bb852654673536", null ],
    [ "eventCount", "class_event_manager.html#ab74418c8064525f34692dff74dd28d82", null ],
    [ "writeIndex", "class_event_manager.html#ad97f788895da6e30b3237982a7bcd810", null ],
    [ "eventMutex", "class_event_manager.html#a970381a54ae432d262830ad74048c94e", null ],
    [ "nextEventId", "class_event_manager.html#a31b1b079c272a1d7022ed84b01927186", null ],
    [ "needsPersistence", "class_event_manager.html#aed2eb3a8bc611f5594eb62304c7b4754", null ]
];