var class_event_manager_impl =
[
    [ "EventManagerImpl", "class_event_manager_impl.html#a07861026e9c06832168372f64e958073", null ],
    [ "saveToStorage", "class_event_manager_impl.html#a8bd15b8b1b4d2439740934f087d97f98", null ],
    [ "loadFromStorage", "class_event_manager_impl.html#ada54a3fd8ad03891318e203ad0a82155", null ]
];