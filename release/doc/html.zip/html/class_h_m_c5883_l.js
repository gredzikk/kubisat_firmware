var class_h_m_c5883_l =
[
    [ "HMC5883L", "class_h_m_c5883_l.html#ac94bd9588bfaecdf6d1aa56915799212", null ],
    [ "init", "class_h_m_c5883_l.html#aacf8416e7f9802ccf993b3e6c0dfe17b", null ],
    [ "read", "class_h_m_c5883_l.html#a8d34ff9a8ff20e12320df6ce5d64397f", null ],
    [ "writeRegister", "class_h_m_c5883_l.html#a114c069b8221f2780b928063a393a183", null ],
    [ "readRegisters", "class_h_m_c5883_l.html#a4a09a4be85064748579e1d44d8f1b305", null ],
    [ "i2c", "class_h_m_c5883_l.html#a5e63fceb40ec1b9427757a4ee206b12f", null ],
    [ "address", "class_h_m_c5883_l.html#ab0f984a6afb4c434cb32d736a9aaa671", null ]
];