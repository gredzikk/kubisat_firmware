var class_h_m_c5883_l_wrapper =
[
    [ "HMC5883LWrapper", "class_h_m_c5883_l_wrapper.html#af0a0709fd3f48d8343794da5b3ee4f32", null ],
    [ "init", "class_h_m_c5883_l_wrapper.html#ab7a5997ae98ed9bc37fdd5ab0afe2fb2", null ],
    [ "readData", "class_h_m_c5883_l_wrapper.html#a76c63b1af36c160c9e7ebf7dc10f872b", null ],
    [ "isInitialized", "class_h_m_c5883_l_wrapper.html#abacf4eeaaff893112e1aa3c20b23ce38", null ],
    [ "getType", "class_h_m_c5883_l_wrapper.html#a655c92b4d2040e76636a96f9ba63c56a", null ],
    [ "configure", "class_h_m_c5883_l_wrapper.html#aae28a5412098db267c5f61a638fa3ef6", null ],
    [ "sensor", "class_h_m_c5883_l_wrapper.html#a676ad07965bad428b637c46152b7c6eb", null ],
    [ "initialized", "class_h_m_c5883_l_wrapper.html#af52be1c1aad99526965b952521da56f6", null ]
];