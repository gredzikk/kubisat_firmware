var class_sensor_wrapper =
[
    [ "SensorWrapper", "class_sensor_wrapper.html#a1702516a09884caf599fad7761dd04c1", null ],
    [ "getInstance", "class_sensor_wrapper.html#adac086bdfb57168899df56fc431c5f41", null ],
    [ "initSensor", "class_sensor_wrapper.html#acbec9bb41e3edd34146eacbf23a807a1", null ],
    [ "configureSensor", "class_sensor_wrapper.html#aeaa7bbc1f7d31212348fd617392cc8d4", null ],
    [ "readSensorData", "class_sensor_wrapper.html#a1b30eac9a56098470f130754134057b9", null ],
    [ "sensors", "class_sensor_wrapper.html#ae06e367395181a74d676c533393b47be", null ]
];