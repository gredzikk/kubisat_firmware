var clock__commands_8cpp =
[
    [ "handleTime", "group___clock_commands.html#ga1eefb8c4d539d50c787b4db3f6ebb093", null ],
    [ "handleTimezoneOffset", "group___clock_commands.html#ga9378f580aefefb566c6f7d49975afeba", null ],
    [ "handleClockSyncInterval", "group___clock_commands.html#gad92a65bf7ca7a1c1ed7b29e5e9e75fa0", null ],
    [ "handleGetLastSyncTime", "group___clock_commands.html#ga17274560343c34119630b27d88ef475e", null ],
    [ "systemClock", "group___clock_commands.html#gabfd573c8a839ac00ea3b96d691ea11c3", null ]
];