var communication_8h =
[
    [ "initializeRadio", "communication_8h.html#a520df448c1dc359f42111ac240081975", null ],
    [ "sendMessage", "communication_8h.html#a877f9c1d3485cf1521bc13996d39c1fb", null ],
    [ "sendLargePacket", "communication_8h.html#a252a4ea5f222c6879d281cc2f9357b46", null ],
    [ "onReceive", "communication_8h.html#a54817002e33761dc61558b1138749dfb", null ],
    [ "handleUartInput", "communication_8h.html#ac5e175a6a1482f700f9aee0b727b924f", null ],
    [ "processFrameData", "communication_8h.html#a8b9407b2f579031cf4b705f1ac03ac31", null ],
    [ "handleCommandFrame", "communication_8h.html#a3ea1f464aef22cd9918b6fe75659c535", null ],
    [ "executeCommand", "group___command_system.html#ga1907d400d2c8d8d054ba95bcf43276ea", null ],
    [ "sendEventRegister", "communication_8h.html#a6005ddd6320bebe2a680fa6b8efff6dd", null ],
    [ "encodeFrame", "communication_8h.html#ab53898fb6f45dfc657837a665a070959", null ],
    [ "decodeFrame", "communication_8h.html#a8f34bc31494430539db21206f084d39d", null ],
    [ "buildFrame", "communication_8h.html#a54afeb73435419551a1b51a3fd5c3266", null ],
    [ "determineUnit", "communication_8h.html#a6272bef4a482127bfe7c1b50d723d69d", null ],
    [ "sendFrame", "communication_8h.html#a752e7cc27f52d4ba064e691b3e240ed8", null ]
];