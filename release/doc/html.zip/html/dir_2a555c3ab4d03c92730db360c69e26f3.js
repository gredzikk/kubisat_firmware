var dir_2a555c3ab4d03c92730db360c69e26f3 =
[
    [ "INA3221", "dir_5d0a4b0911b9c8b26297ef3cfa2d24e2.html", "dir_5d0a4b0911b9c8b26297ef3cfa2d24e2" ],
    [ "PowerManager.cpp", "_power_manager_8cpp.html", null ],
    [ "PowerManager.h", "_power_manager_8h.html", "_power_manager_8h" ]
];