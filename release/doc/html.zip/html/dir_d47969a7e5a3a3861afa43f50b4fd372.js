var dir_d47969a7e5a3a3861afa43f50b4fd372 =
[
    [ "HMC5883L.cpp", "_h_m_c5883_l_8cpp.html", null ],
    [ "HMC5883L.h", "_h_m_c5883_l_8h.html", "_h_m_c5883_l_8h" ],
    [ "HMC5883L_WRAPPER.cpp", "_h_m_c5883_l___w_r_a_p_p_e_r_8cpp.html", null ],
    [ "HMC5883L_WRAPPER.h", "_h_m_c5883_l___w_r_a_p_p_e_r_8h.html", "_h_m_c5883_l___w_r_a_p_p_e_r_8h" ]
];