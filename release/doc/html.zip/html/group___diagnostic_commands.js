var group___diagnostic_commands =
[
    [ "handleListCommands", "group___diagnostic_commands.html#gade74b82cf2c20d93c5e0ce624cd7ca77", null ],
    [ "handleGetBuildVersion", "group___diagnostic_commands.html#ga5ebac5711334cb3584974b2b74556543", null ],
    [ "handleEnterBootloaderMode", "group___diagnostic_commands.html#ga3a6c6092cd01fd9c13ab429f4a34326d", null ]
];