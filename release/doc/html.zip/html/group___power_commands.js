var group___power_commands =
[
    [ "handleGetPowerManagerIDs", "group___power_commands.html#gafef922e13071e5fb67da78207a9f22a4", null ],
    [ "handleGetVoltageBattery", "group___power_commands.html#gad301b8c13cafa148a6f3e80e9b0bcf1a", null ],
    [ "handleGetVoltage5V", "group___power_commands.html#ga9f2b608f46080fcdae38a1a8454938b8", null ],
    [ "handleGetCurrentChargeUSB", "group___power_commands.html#ga3f38c538065bf67dbec1142fdb866d16", null ],
    [ "handleGetCurrentChargeSolar", "group___power_commands.html#ga6fbaf484e68c9561ad7fabef21def37b", null ],
    [ "handleGetCurrentChargeTotal", "group___power_commands.html#ga83596ea837df6cf7b15e673b95bf524f", null ],
    [ "handleGetCurrentDraw", "group___power_commands.html#gabd6610f557fe9deaa9f80d9405738226", null ]
];