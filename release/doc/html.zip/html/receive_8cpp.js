var receive_8cpp =
[
    [ "onReceive", "receive_8cpp.html#a54817002e33761dc61558b1138749dfb", null ],
    [ "handleUartInput", "receive_8cpp.html#ac5e175a6a1482f700f9aee0b727b924f", null ]
];