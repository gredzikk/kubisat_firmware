var searchData=
[
  ['uart_5ferror_0',['UART_ERROR',['../event__manager_8h.html#a0270a0464efae26aefb8cf32a45e20adae7987a4741412b725a5a1a24867f9b62',1,'event_manager.h']]],
  ['uart_5fmutex_1',['uart_mutex',['../utils_8cpp.html#a1a79e1136e3879e08124c966946cf7b4',1,'utils.cpp']]],
  ['uartprint_2',['uartPrint',['../utils_8cpp.html#aacbcecbe6b5428e3571b06ab2104e706',1,'uartPrint(const std::string &amp;msg, bool logToFile, uart_inst_t *uart):&#160;utils.cpp'],['../utils_8h.html#a581207ee5c53ce94cdf3279a0f66f564',1,'uartPrint(const std::string &amp;msg, bool logToFile=false, uart_inst_t *uart=DEBUG_UART_PORT):&#160;utils.cpp']]],
  ['unconfigured_5fpower_5fdown_3',['UNCONFIGURED_POWER_DOWN',['../class_b_h1750.html#a8402147d4b96294da6362b538d4827c0a9d4b69a5f725a5105a480e2e5d67e851',1,'BH1750']]],
  ['undefined_4',['UNDEFINED',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8fa0db45d2a4141101bdfe48e3314cfbca3',1,'protocol.h']]],
  ['unit_5',['unit',['../struct_frame.html#a6481c04c9c112a41a50c24696454afa8',1,'Frame']]],
  ['unixtodatetime_6',['unixToDateTime',['../class_d_s3231.html#a40a965b965496e5b0e7758040c5d9ce7',1,'DS3231']]],
  ['updateggatokens_7',['updateGgaTokens',['../class_n_m_e_a_data.html#a8a15909a8db61c8c49e18ddf150ab72c',1,'NMEAData']]],
  ['updatermctokens_8',['updateRmcTokens',['../class_n_m_e_a_data.html#ace48ac42e9e5af14820ea685b90fcf85',1,'NMEAData']]],
  ['usb_5fconnected_9',['USB_CONNECTED',['../event__manager_8h.html#a8b04683add0105a3bf3200eee3d9d3e6aea2afd0110180e8af5bf95a583f9dd13',1,'event_manager.h']]],
  ['usb_5fcurrent_5fthreshold_10',['USB_CURRENT_THRESHOLD',['../class_power_manager.html#afc4246cc3b434053c59cf2dcccf4bc64',1,'PowerManager']]],
  ['usb_5fdisconnected_11',['USB_DISCONNECTED',['../event__manager_8h.html#a8b04683add0105a3bf3200eee3d9d3e6a3a026550c6805c690d88a618aff891c9',1,'event_manager.h']]],
  ['usbconnected_12',['usbConnected',['../class_power_manager.html#a3676187deac57a79034f59f58ac4b746',1,'PowerManager']]],
  ['utils_2ecpp_13',['utils.cpp',['../utils_8cpp.html',1,'']]],
  ['utils_2eh_14',['utils.h',['../utils_8h.html',1,'']]],
  ['utils_5fconverters_2ecpp_15',['utils_converters.cpp',['../utils__converters_8cpp.html',1,'']]]
];
