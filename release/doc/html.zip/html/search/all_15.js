var searchData=
[
  ['year_0',['year',['../struct_date_time.html#a0a61d60280541502e47f9a7fd6e1c8d2',1,'DateTime']]]
];
