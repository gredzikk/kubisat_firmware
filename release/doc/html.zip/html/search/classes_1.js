var searchData=
[
  ['conf_5freg_5ft_0',['conf_reg_t',['../struct_i_n_a3221_1_1conf__reg__t.html',1,'INA3221']]]
];
