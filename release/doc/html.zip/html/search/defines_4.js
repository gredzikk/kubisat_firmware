var searchData=
[
  ['gps_5fpower_5fenable_5fpin_0',['GPS_POWER_ENABLE_PIN',['../pin__config_8h.html#aac8b46194f932ec0656edff3718d3750',1,'pin_config.h']]],
  ['gps_5fuart_5fbaud_5frate_1',['GPS_UART_BAUD_RATE',['../pin__config_8h.html#aff9a5d52092479f80c68a37d9f47ea0c',1,'pin_config.h']]],
  ['gps_5fuart_5fport_2',['GPS_UART_PORT',['../pin__config_8h.html#a31bae3288bdf1b7a767c494f2b049779',1,'pin_config.h']]],
  ['gps_5fuart_5frx_5fpin_3',['GPS_UART_RX_PIN',['../pin__config_8h.html#a8d2d12725644a55f56e8aee18942b144',1,'pin_config.h']]],
  ['gps_5fuart_5ftx_5fpin_4',['GPS_UART_TX_PIN',['../pin__config_8h.html#a8e35acac4c2208fd0d6b889990c1f970',1,'pin_config.h']]]
];
