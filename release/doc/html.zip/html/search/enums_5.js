var searchData=
[
  ['operationtype_0',['OperationType',['../protocol_8h.html#a9a2c9c31d675b34f6ec35cc1ca89e047',1,'protocol.h']]]
];
