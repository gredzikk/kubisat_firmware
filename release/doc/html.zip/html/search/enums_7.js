var searchData=
[
  ['sensordatatypeidentifier_0',['SensorDataTypeIdentifier',['../_i_sensor_8h.html#a21b0301bb3eb76855366980212c8ae5e',1,'ISensor.h']]],
  ['sensortype_1',['SensorType',['../_i_sensor_8h.html#a213c434cb928c4ca22513e2302632435',1,'ISensor.h']]],
  ['systemevent_2',['SystemEvent',['../event__manager_8h.html#a77219d2f280eaad8c79825f50cf78785',1,'event_manager.h']]]
];
