var searchData=
[
  ['bool_0',['BOOL',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8faa97b2c144243b2b9d2c593ec268b62f5',1,'protocol.h']]],
  ['boot_1',['BOOT',['../event__manager_8h.html#a77219d2f280eaad8c79825f50cf78785adf9a77cdc2fe29972274b189cf7bac7c',1,'event_manager.h']]]
];
