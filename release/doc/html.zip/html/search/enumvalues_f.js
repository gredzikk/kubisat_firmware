var searchData=
[
  ['temperature_0',['TEMPERATURE',['../_i_sensor_8h.html#a21b0301bb3eb76855366980212c8ae5eab976538812ef6e3e5881e245d5fc3c76',1,'ISensor.h']]],
  ['text_1',['TEXT',['../protocol_8h.html#a2d96449e2b52d45b5726af92084e0d8fa61a96ffcb251bb9bf0abf8fec19d0ea8',1,'protocol.h']]]
];
