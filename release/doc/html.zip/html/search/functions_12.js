var searchData=
[
  ['uartprint_0',['uartPrint',['../utils_8cpp.html#aacbcecbe6b5428e3571b06ab2104e706',1,'uartPrint(const std::string &amp;msg, bool logToFile, uart_inst_t *uart):&#160;utils.cpp'],['../utils_8h.html#a581207ee5c53ce94cdf3279a0f66f564',1,'uartPrint(const std::string &amp;msg, bool logToFile=false, uart_inst_t *uart=DEBUG_UART_PORT):&#160;utils.cpp']]],
  ['unixtodatetime_1',['unixToDateTime',['../class_d_s3231.html#a40a965b965496e5b0e7758040c5d9ce7',1,'DS3231']]],
  ['updateggatokens_2',['updateGgaTokens',['../class_n_m_e_a_data.html#a8a15909a8db61c8c49e18ddf150ab72c',1,'NMEAData']]],
  ['updatermctokens_3',['updateRmcTokens',['../class_n_m_e_a_data.html#ace48ac42e9e5af14820ea685b90fcf85',1,'NMEAData']]]
];
