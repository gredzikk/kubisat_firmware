var searchData=
[
  ['bcd2bin_0',['bcd2bin',['../class_d_s3231.html#a389e756fdd8f645d6025906bbce5abd8',1,'DS3231']]],
  ['begin_1',['begin',['../class_lo_ra_class.html#a3c5b6ee156c14f20238f46292c116d96',1,'LoRaClass::begin()'],['../class_i_n_a3221.html#a868af24425b042f330a0e7fae8210936',1,'INA3221::begin()'],['../class_b_h1750.html#ae0e57ed9ecc08464a6b98b733d420e11',1,'BH1750::begin()']]],
  ['beginpacket_2',['beginPacket',['../class_lo_ra_class.html#a22d4ee8aaded004bb91b70ee15c57e2d',1,'LoRaClass']]],
  ['bh1750_3',['BH1750',['../class_b_h1750.html#ad3621c02c56c15e4f3d40f0974a376f2',1,'BH1750']]],
  ['bh1750wrapper_4',['BH1750Wrapper',['../class_b_h1750_wrapper.html#a269ed77d8ed445c6fb4a9aa6f33b39df',1,'BH1750Wrapper']]],
  ['bin2bcd_5',['bin2bcd',['../class_d_s3231.html#a41f5aabf74e5a66093116999648806ab',1,'DS3231']]],
  ['bme280_6',['BME280',['../class_b_m_e280.html#a2f0c3415c853ed9303529b75d5d7236b',1,'BME280']]],
  ['bme280wrapper_7',['BME280Wrapper',['../class_b_m_e280_wrapper.html#aae6146a4d2637870a28e2cc2391663f7',1,'BME280Wrapper']]],
  ['buildframe_8',['buildFrame',['../communication_8h.html#a54afeb73435419551a1b51a3fd5c3266',1,'buildFrame(ExecutionResult result, uint8_t group, uint8_t command, const std::string &amp;value, const ValueUnit unitType=ValueUnit::UNDEFINED):&#160;frame.cpp'],['../frame_8cpp.html#a5f43260949ee244d3ee66068eb1d7fc1',1,'buildFrame(ExecutionResult result, uint8_t group, uint8_t command, const std::string &amp;value, const ValueUnit unitType):&#160;frame.cpp']]]
];
