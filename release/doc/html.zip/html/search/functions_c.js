var searchData=
[
  ['nmeadata_0',['NMEAData',['../class_n_m_e_a_data.html#aff10b3badea9258591a2d1eeb601e519',1,'NMEAData']]],
  ['nocrc_1',['noCrc',['../class_lo_ra_class.html#a233f3f02961eb108ba509a8147237028',1,'LoRaClass']]]
];
