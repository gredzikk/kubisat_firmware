var searchData=
[
  ['power_20commands_0',['Power Commands',['../group___power_commands.html',1,'']]]
];
