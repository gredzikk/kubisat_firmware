var searchData=
[
  ['buffer_0',['buffer',['../main_8cpp.html#af00b615ca097c43dbb02ae3a00ea3a62',1,'main.cpp']]],
  ['bufferindex_1',['bufferIndex',['../main_8cpp.html#a73b963945a418c57630c1b66ce2aa74f',1,'main.cpp']]],
  ['bus_5fconv_5ftime_2',['bus_conv_time',['../struct_i_n_a3221_1_1conf__reg__t.html#ae5d8ffdeff64ebc70c018901b6e45319',1,'INA3221::conf_reg_t']]]
];
