var searchData=
[
  ['fall_5frate_5fthreshold_0',['FALL_RATE_THRESHOLD',['../class_power_manager.html#aae449340ac8e77b181ef2f0abd2d96ed',1,'PowerManager::FALL_RATE_THRESHOLD'],['../event__manager_8cpp.html#a234988dfb88db38997bd921cd5c32457',1,'FALL_RATE_THRESHOLD:&#160;event_manager.cpp']]],
  ['falling_5ftrend_5frequired_1',['FALLING_TREND_REQUIRED',['../class_power_manager.html#a17e01551bc0f14820b2430d697c4c6d2',1,'PowerManager::FALLING_TREND_REQUIRED'],['../event__manager_8cpp.html#ae4e7da8cdf52e447acd5705d930759cf',1,'FALLING_TREND_REQUIRED:&#160;event_manager.cpp']]],
  ['fallingtrendcount_2',['fallingTrendCount',['../event__manager_8cpp.html#ad4a2e48e0a0e0d5aa49dd6c2aa12d8fb',1,'event_manager.cpp']]],
  ['fd_3',['fd',['../struct_file_handle.html#afc2bbe66c168d4d264f3af1ec037b122',1,'FileHandle']]],
  ['footer_4',['footer',['../struct_frame.html#a30e584ccb03562f0bbd5356562a462c1',1,'Frame']]],
  ['frame_5fbegin_5',['FRAME_BEGIN',['../protocol_8h.html#aa6688ce7f01167c4ecb45cc4c741cca0',1,'protocol.h']]],
  ['frame_5fend_6',['FRAME_END',['../protocol_8h.html#a38fcd5426cc3ba27b4260e4db4299072',1,'protocol.h']]]
];
