var searchData=
[
  ['gga_5fmutex_0',['gga_mutex',['../class_n_m_e_a_data.html#afe04b61742fac871746c1c2d4ef0aa17',1,'NMEAData']]],
  ['ggatokens_1',['ggaTokens',['../class_n_m_e_a_data.html#a26084e69305d4565dd1372e2004d6c98',1,'NMEAData']]],
  ['group_2',['group',['../struct_frame.html#abd1ff8cb6b3d53706a97ea15727ddd4f',1,'Frame::group'],['../class_event_log.html#a5209ffdb8dc4bf7f87f3ec44b2ae63e3',1,'EventLog::group'],['../event__manager_8h.html#ad4291fcb880eb5ecb178b53e32f55741',1,'group:&#160;event_manager.h']]]
];
