var searchData=
[
  ['header_0',['header',['../struct_frame.html#ae969aefac1bd27476536aae3de4eacee',1,'Frame']]],
  ['hour_1',['hour',['../struct_date_time.html#ad7812eb3752d2309263267d4bc3c79a0',1,'DateTime']]]
];
