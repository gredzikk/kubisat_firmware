var send_8cpp =
[
    [ "sendMessage", "send_8cpp.html#adcc720dc971ce8b237b26df434b65bb2", null ],
    [ "sendFrame", "send_8cpp.html#a752e7cc27f52d4ba064e691b3e240ed8", null ],
    [ "sendLargePacket", "send_8cpp.html#a252a4ea5f222c6879d281cc2f9357b46", null ]
];