var struct_file_handle =
[
    [ "fd", "struct_file_handle.html#afc2bbe66c168d4d264f3af1ec037b122", null ],
    [ "is_open", "struct_file_handle.html#a1c2451d05e2d2937da92fe194e9281cf", null ]
];